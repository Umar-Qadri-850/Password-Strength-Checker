const passwordInput = document.getElementById('password');
const strengthBar = document.getElementById('strength-bar');
const feedback = document.getElementById('feedback');

passwordInput.addEventListener('input', () => {
  const password = passwordInput.value;
  const strength = calculateStrength(password);
  updateUI(strength, password);
});

function calculateStrength(password) {
  let strength = 0;

  if (password.length >= 8) strength++;
  if (/[A-Z]/.test(password)) strength++;
  if (/[0-9]/.test(password)) strength++;
  if (/[^A-Za-z0-9]/.test(password)) strength++;

  return strength;
}

function updateUI(strength, password) {
  const colors = ['red', 'orange', 'yellow', 'lightgreen', 'green'];
  const feedbackMessages = [
    "Very Weak 💀",
    "Weak 😞",
    "Moderate 😐",
    "Strong 💪",
    "Very Strong 🔥"
  ];

  const width = (strength / 4) * 100;
  strengthBar.style.width = width + '%';
  strengthBar.style.backgroundColor = colors[strength];
  feedback.textContent = password ? feedbackMessages[strength] : '';
}
